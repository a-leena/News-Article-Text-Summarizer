function getText(event) {
    var text = event.target.value;
    console.log(text);
    var count = text.length;
    document.getElementById("wordcount").innerHTML = count;
    var button = document.getElementById("summarize");
    var summary = document.getElementById("summary");
    if (text.length==0) {
        button.disabled = true;
        if (summary.innerHTML.length != 0) {
            var heading = document.getElementById("recentHeading")
            summary.innerHTML = "";
        }

    }
    else {
        button.disabled = false;
    }
}

function generateSummary() {
    console.log("we're in");
    document.getElementById("summary").innerHTML = "this is the summary";
}